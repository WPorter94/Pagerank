William Porter 27879830

OverView
Unfortunately the I dont understand how to calculate L2 Norm, i feel like the project still works and gets almost proer results just half as alrge

Libraries
GZIP library for unpacking .gz files
random library to get random numbers
math library for square root function
Dependencies
None

Building/ Running
Simply run "python pagerank.py" followed by optional arguments in a command prompt opened where pagera